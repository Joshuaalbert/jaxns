"""Coordinator raw archive/evidence checks, independent of benchmark helpers."""

import hashlib
import json
from pathlib import Path

import numpy as np


root = Path('/largedata/albert/jaxns-reflection-duration-20261027')
freeze_path = root/'SOURCE_FREEZE.json'
freeze = json.loads(freeze_path.read_text())
freeze_hash = hashlib.sha256(freeze_path.read_bytes()).hexdigest()
release = json.loads((root/'EVALUATION_RELEASE.json').read_text())
assert release['approved'] and release['source_commit'] == freeze['source_commit']
assert release['source_freeze_sha256'] == freeze_hash
schedule_path = root/'SCHEDULE.json'
schedule_hash = hashlib.sha256(schedule_path.read_bytes()).hexdigest()
assert schedule_hash == '21242cb5554c0b7c23c4750d1c8aa579e3d9856ff670a0f9c18133b1771a28d6'
schedule = json.loads(schedule_path.read_text())
arms = ('fixed', 'short', 'duration')
allocations = ('uniform', 'evidence_improving')
budgets = (2000000, 4000000)
rows = []
matched_priors = {}
source_hashes = None
maximum_likelihood_error = 0.
peak = -np.log(1e-5*np.sqrt(2*np.pi))-14*np.log(.05*np.sqrt(2*np.pi))
for arm in arms:
    for allocation in allocations:
        for seed in range(30, 60):
            folder = root/'runs'/arm/allocation/f'seed-{seed:02d}'
            manifest = json.loads((folder/'MANIFEST.json').read_text())
            complete = json.loads((folder/'ANALYSIS-COMPLETE.json').read_text())
            assert complete['passed'] and complete['evidence_complete']
            assert manifest['arm'] == arm and manifest['allocation'] == allocation
            assert manifest['seed'] == seed and not manifest['smoke']
            assert manifest['backend'] == 'cpu' and manifest['unit_dtype'] == 'float64'
            assert manifest['commit'] == freeze['source_commit']
            assert manifest['source_freeze_sha256'] == freeze_hash
            assert manifest['protocol_sha256'] == freeze['protocol_sha256']
            assert manifest['record_schema'] == 2 and manifest['comparison'] == 'duration'
            assert len(manifest['cpu_affinity']) == 1
            assert manifest['kernel'] == {
                'num_cycles': 9, 'slices_per_cycle': 1,
                'num_bounces': 10, 'step_size': .003,
            }
            assert manifest['thread_environment']['JAX_PLATFORMS'] == 'cpu'
            assert manifest['thread_environment']['CUDA_VISIBLE_DEVICES'] == ''
            assert manifest['schedule_sha256'] == schedule_hash
            if source_hashes is None:
                source_hashes = manifest['source_sha256']
            assert source_hashes == manifest['source_sha256']
            for budget in budgets:
                row = json.loads((folder/f'ANALYSIS-{budget}.json').read_text())
                raw_path = folder/f'calls-{budget}.npz'
                input_path = folder/f'inputs-{budget}.npz'
                draw_path = folder/f'evidence-{budget}.npz'
                for path, field in ((raw_path,'archive_sha256'),
                                    (input_path,'phantom_archive_sha256'),
                                    (draw_path,'evidence_sha256')):
                    assert hashlib.sha256(path.read_bytes()).hexdigest() == row[field]
                with np.load(raw_path, allow_pickle=False) as data:
                    x = data['unit_samples']
                    likelihood = data['log_likelihood']
                    constraint = data['log_L_constraints']
                    evaluations = data['evaluations_per_sample']
                    seeds = data['seed_indices']
                    parents = data['parent_indices']
                    log_weights = data['log_weights']
                    stored_bounces = data['bounce_counts']
                    stored_steps = data['nominal_steps']
                    stored_gradients = data['gradient_evaluations_per_sample']
                    stored_values = data['value_only_evaluations_per_sample']
                    batches = data['batch_indices']
                n = len(x)
                roots = seeds < 0
                assert x.shape == (row['samples'], 18) and x.dtype == np.float64
                assert np.all((x >= 0) & (x <= 1)) and np.all(likelihood > constraint)
                assert np.array_equal(roots, parents < 0)
                assert np.array_equal(roots, np.isneginf(constraint))
                assert np.all(evaluations[roots] == 1)
                assert roots.sum() == row['roots'] and evaluations.sum() == row['evaluations']
                gaps = schedule['peak'] - constraint
                old_h = np.where(
                    gaps > schedule['gaps'][-1], .003,
                    np.exp(np.interp(np.log(np.maximum(gaps, schedule['gaps'][0])),
                                     np.log(schedule['gaps']), np.log(schedule['steps']))),
                )
                bounces = (np.ceil(.03 / old_h).astype(np.int64)
                           if arm == 'duration' else np.full(n, 10, np.int64))
                bounces = np.where(gaps > schedule['gaps'][-1], 10, bounces)
                gradients = np.where(roots, 0, 9 * bounces)
                np.testing.assert_array_equal(stored_bounces, np.where(roots, 0, bounces))
                np.testing.assert_array_equal(stored_gradients, gradients)
                np.testing.assert_array_equal(stored_values, evaluations - gradients)
                assert row['gradient_evaluations'] == gradients.sum()
                assert row['value_only_evaluations'] == evaluations.sum() - gradients.sum()
                assert np.all(evaluations[~roots] >= gradients[~roots] + 18)
                with np.load(folder/'chain-diagnostics.npz', allow_pickle=False) as diagnostics:
                    steps = diagnostics['realised_steps'][:n]
                    accepted = diagnostics['reflection_accepted'][:n]
                assert steps.shape == (n, 9)
                assert np.all((accepted[~roots] >= 0) & (accepted[~roots] <= 9))
                h = (.03 / bounces if arm == 'duration' else
                     old_h if arm == 'short' else np.full(n, .003))
                np.testing.assert_allclose(stored_steps[~roots], h[~roots], rtol=2e-14, atol=0)
                assert np.all(stored_steps[roots] == 0)
                assert np.all(steps[~roots] >= .8 * h[~roots, None] * (1 - 1e-14))
                assert np.all(steps[~roots] <= 1.2 * h[~roots, None] * (1 + 1e-14))
                if arm == 'duration':
                    time = steps[~roots] * bounces[~roots, None]
                    assert np.all(time >= .024 * (1 - 1e-14))
                    assert np.all(time <= .036 * (1 + 1e-14))
                assert row['evaluations_before_last_batch'] < budget <= row['evaluations']
                assert row['evaluations']-row['evaluations_before_last_batch'] == row['last_batch_evaluations']
                assert evaluations[batches == batches.max()].sum() == row['last_batch_evaluations']
                assert np.all(seeds[~roots] < np.flatnonzero(~roots))
                assert np.all(batches[seeds[~roots]] < batches[~roots])
                np.testing.assert_array_equal(likelihood[parents[~roots]], constraint[~roots])
                assert np.all(likelihood[seeds[~roots]] > constraint[~roots])
                reference = peak-.5*((x[:,0]-.5-.3*np.sin(2*np.pi*x[:,1]))/1e-5)**2
                reference -= .5*np.sum(((x[:,2:16]-.5)/.05)**2, axis=1)
                error = float(np.max(abs(reference-likelihood)))
                assert error < 5e-5
                maximum_likelihood_error = max(maximum_likelihood_error, error)
                digest = hashlib.sha256(x[:150].tobytes()+likelihood[:150].tobytes()).hexdigest()
                assert digest == row['initial_sha256']
                if seed in matched_priors:
                    assert matched_priors[seed] == digest
                matched_priors[seed] = digest
                weights = np.exp(log_weights-log_weights.max())
                weights /= weights.sum()
                mean = np.sum(weights[:,None]*x,axis=0)
                std = np.sqrt(np.sum(weights[:,None]*(x-mean)**2,axis=0))
                np.testing.assert_allclose(mean,row['mean'],rtol=1e-12,atol=1e-14)
                np.testing.assert_allclose(std,row['std'],rtol=1e-12,atol=1e-14)
                for movement in row['movement']:
                    high = np.inf if movement['gap_high'] is None else movement['gap_high']
                    selection = (~roots) & (gaps > movement['gap_low']) & (gaps <= high)
                    number = int(selection.sum())
                    assert movement['pairs'] == number
                    if number:
                        assert movement['gradient_evaluations'] == gradients[selection].sum()
                        np.testing.assert_equal(movement['acceptance'],
                                                accepted[selection].sum() / (9 * number))
                    if number >= 30:
                        for coordinate in (1, 16, 17, 5):
                            displacement = x[selection, coordinate] - x[seeds[selection], coordinate]
                            squared_sum = np.sum(displacement ** 2)
                            np.testing.assert_equal(movement[f'squared_displacement_sum_x{coordinate}'],
                                                    squared_sum)
                            np.testing.assert_equal(movement[f'esjd_dx{coordinate}_per_gradient'],
                                                    squared_sum / gradients[selection].sum())
                with np.load(input_path,allow_pickle=False) as data:
                    valid = data['valid_phantom']
                    phantom = data['log_L_phantom']
                    np.testing.assert_array_equal(data['log_L_classic'][:n],likelihood)
                    np.testing.assert_array_equal(valid[:n],~roots)
                    assert not valid[n:].any() and phantom.shape[1] == 8
                    assert np.all(phantom[:n][~roots] > constraint[~roots,None])
                with np.load(draw_path,allow_pickle=False) as draws:
                    for mode in ('classic_mc','phantom'):
                        z = draws[f'{mode}_log_Z_samples']
                        assert z.shape == (4096,) and np.isfinite(z).all()
                        np.testing.assert_equal(z.mean(),row[f'{mode}_log_Z'])
                        np.testing.assert_equal(z.std(),row[f'{mode}_log_Z_uncert'])
                        np.testing.assert_equal(z.std(ddof=1)/64,row[f'{mode}_mcse'])
                rows.append(row)
assert len(rows) == 360 and len(matched_priors) == 30
summary = []
contrasts = []
rng = np.random.default_rng(3122714)
bootstrap = rng.integers(0,30,size=(100000,30))
for allocation in allocations:
    for budget in budgets:
        for mode in ('classic','classic_mc','phantom'):
            field = 'log_Z' if mode == 'classic' else f'{mode}_log_Z'
            vectors = {}
            for arm in arms:
                selected = sorted((r for r in rows if r['arm']==arm and
                                   r['allocation']==allocation and r['budget']==budget),
                                  key=lambda r:r['seed'])
                assert [r['seed'] for r in selected] == list(range(30, 60))
                z = np.array([r[field] for r in selected])
                vectors[arm] = z
                sd_field = 'log_Z_uncert' if mode=='classic' else f'{mode}_log_Z_uncert'
                summary.append({'allocation':allocation,'budget':budget,'mode':mode,'arm':arm,
                                'rmse':float(np.sqrt(np.mean(z*z))),'bias':float(z.mean()),
                                'mean_quoted_sd':float(np.mean([r[sd_field] for r in selected]))})
            for left, right in (('duration', 'short'), ('duration', 'fixed'), ('short', 'fixed')):
                boot_delta = (np.sqrt(np.mean(vectors[left][bootstrap]**2, axis=1)) -
                              np.sqrt(np.mean(vectors[right][bootstrap]**2, axis=1)))
                contrasts.append({
                    'allocation': allocation, 'budget': budget, 'mode': mode,
                    'contrast': f'{left}_minus_{right}',
                    'delta_rmse': float(np.sqrt(np.mean(vectors[left]**2)) -
                                        np.sqrt(np.mean(vectors[right]**2))),
                    'paired_percentile95': np.quantile(boot_delta, [.025, .975]).tolist(),
                })
report = {'passed':True,'raw_snapshots':360,'runs':180,'matched_prior_seeds':30,
          'schedule_sha256':schedule_hash,'max_likelihood_discrepancy':maximum_likelihood_error,
          'source_commit':freeze['source_commit'],'source_freeze_sha256':freeze_hash,
          'all_cpu_and_float64':True,'summary':summary,'contrasts':contrasts,
          'audit_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root/'coordinator-audits/COHORT_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key: report[key] for key in ('passed','raw_snapshots','runs','max_likelihood_discrepancy')}))
print(json.dumps([item for item in summary if item['budget'] == 4000000], indent=2))
