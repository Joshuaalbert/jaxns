"""Coordinator preflight: independent smoke ledgers and immutable evaluation release."""
import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import subprocess

os.sched_setaffinity(0, {70})
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--release', action='store_true')
options = parser.parse_args()
root = Path('/largedata/albert/jaxns-reflection-duration-20261027')
source = Path('/largedata/albert/git/jaxns-reflection-duration-20261027')
expected_commit = '724d5e9a94d2db417573cd8cc473224e82a60a13'
freeze_path = root/'SOURCE_FREEZE.json'
freeze = json.loads(freeze_path.read_text())
freeze_hash = hashlib.sha256(freeze_path.read_bytes()).hexdigest()
assert freeze['source_commit'] == expected_commit
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == expected_commit
for relative, digest in freeze['source_sha256'].items():
    assert hashlib.sha256((source/relative).read_bytes()).hexdigest() == digest, relative
assert freeze['protocol_sha256'] == '44154ae79a7d91408c43fcb81f7a8edcf2c264c95205aa22f47d0723bfa5782b'
assert freeze['schedule_sha256'] == '21242cb5554c0b7c23c4750d1c8aa579e3d9856ff670a0f9c18133b1771a28d6'
validation_path = root/'validation/VALIDATION.json'
validation_hash = hashlib.sha256(validation_path.read_bytes()).hexdigest()
heldout = json.loads((root/'coordinator-audits/HELDOUT_AUDIT.json').read_text())
assert heldout['passed'] and heldout['cases'] == 21
assert heldout['validation_sha256'] == validation_hash
assert heldout['source_commit'] == expected_commit
assert heldout['source_freeze_sha256'] == freeze_hash
schedule = json.loads((root/'SCHEDULE.json').read_text())
records = []
for name, allocation, seed in [('smoke-duration-uniform', 'uniform', 3122718),
                               ('smoke-duration-evidence', 'evidence_improving', 3122719)]:
    folder = root/name
    manifest = json.loads((folder/'MANIFEST.json').read_text())
    complete = json.loads((folder/'ANALYSIS-COMPLETE.json').read_text())
    assert complete['passed'] and complete['evidence_complete']
    assert manifest['smoke'] and manifest['arm'] == 'duration'
    assert manifest['allocation'] == allocation and manifest['seed'] == seed
    assert manifest['commit'] == expected_commit and manifest['record_schema'] == 2
    assert manifest['backend'] == 'cpu' and manifest['unit_dtype'] == 'float64'
    assert manifest['source_freeze_sha256'] == freeze_hash
    for row in complete['records']:
        with np.load(folder/f"calls-{row['budget']}.npz", allow_pickle=False) as data:
            roots = data['seed_indices'] < 0
            gradient = data['gradient_evaluations_per_sample']
            calls = data['evaluations_per_sample']
            constraints = data['log_L_constraints']
            bounces = data['bounce_counts']
            steps = data['nominal_steps']
            assert roots.sum() == row['roots']
            assert np.all(bounces[roots] == 0) and np.all(steps[roots] == 0)
            assert np.all(gradient[roots] == 0) and np.all(calls[roots] == 1)
            assert np.all(data['value_only_evaluations_per_sample'][roots] == 1)
            gap = schedule['peak']-constraints
            desired = np.where(gap > 49, .003, np.exp(np.interp(
                np.log(np.maximum(gap, schedule['gaps'][0])),
                np.log(schedule['gaps']), np.log(schedule['steps']),
            )))
            expected_b = np.where(roots, 0, np.where(gap > 49, 10, np.ceil(.03/desired)))
            np.testing.assert_array_equal(bounces, expected_b)
            np.testing.assert_array_equal(gradient, 9 * expected_b)
            assert gradient.sum() == row['gradient_evaluations']
            assert calls.sum() == row['evaluations']
            assert (calls-gradient).sum() == row['value_only_evaluations']
            assert row['replay_exact'] and row['audit_passed']
            log_tail = (schedule['peak'] + data['log_volume'][np.argmax(data['log_likelihood'])]
                        - row['log_Z'] - .5*row['log_Z_uncert']**2)
            np.testing.assert_equal(log_tail, row['classic_tail_log_upper_fraction'])
            overflow = log_tail > np.log(np.finfo(np.float64).max)
            assert bool(overflow) == row['classic_tail_upper_fraction_overflow']
            if overflow:
                assert row['classic_tail_upper_fraction'] is None
            else:
                np.testing.assert_equal(np.exp(log_tail), row['classic_tail_upper_fraction'])
        with np.load(folder/f"evidence-{row['budget']}.npz", allow_pickle=False) as draws:
            for mode in ('classic_mc', 'phantom'):
                z = draws[f'{mode}_log_Z_samples']
                assert z.shape == (4096,) and np.isfinite(z).all()
                np.testing.assert_equal(z.mean(), row[f'{mode}_log_Z'])
                np.testing.assert_equal(z.std(), row[f'{mode}_log_Z_uncert'])
        records.append({key: row[key] for key in ('allocation', 'budget', 'roots',
                        'samples', 'gradient_evaluations', 'evaluations',
                        'classic_tail_log_upper_fraction', 'classic_tail_upper_fraction_overflow')})
report = {'passed': True, 'source_commit': expected_commit,
          'source_freeze_sha256': freeze_hash, 'validation_sha256': validation_hash,
          'records': records, 'audit_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
report_path = root/'coordinator-audits/SMOKE_AUDIT.json'
report_path.write_text(json.dumps(report, indent=2)+'\n')
if options.release:
    path = root/'EVALUATION_RELEASE.json'
    assert not path.exists(), 'An evaluation release already exists.'
    payload = {'approved': True, 'approved_utc': datetime.now(timezone.utc).isoformat(),
               'source_commit': expected_commit, 'source_freeze_sha256': freeze_hash,
               'protocol_sha256': freeze['protocol_sha256'],
               'schedule_sha256': freeze['schedule_sha256'],
               'validation_sha256': validation_hash,
               'independent_heldout_audit_sha256': hashlib.sha256((root/'coordinator-audits/HELDOUT_AUDIT.json').read_bytes()).hexdigest(),
               'independent_smoke_audit_sha256': hashlib.sha256(report_path.read_bytes()).hexdigest(),
               'scope': 'Prespecified180 runs,3arms,2allocations,seeds30--59; CPU-only; no retuning.'}
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(payload, indent=2)+'\n')
    temporary.replace(path)
    path.with_suffix('.json.sha256').write_text(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.name+'\n')
print(json.dumps({'passed': True, 'release_published': options.release,
                  'source_commit': expected_commit, 'smoke_records': records}, indent=2))
