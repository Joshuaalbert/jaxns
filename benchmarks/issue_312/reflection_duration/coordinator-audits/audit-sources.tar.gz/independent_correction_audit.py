"""Verify the reporting correction changed only six declared movement fields."""

import hashlib
import json
from pathlib import Path

root = Path('/largedata/albert/jaxns-reflection-duration-20261027')
receipt_path = root/'DIAGNOSTIC_CORRECTION.json'
receipt = json.loads(receipt_path.read_text())
original = root/'pre-movement-diagnostic-correction'
fields = {
    'bounce_count_min', 'bounce_count_max', 'mean_bounce_count',
    'mean_realised_duration', 'duration_min', 'duration_max',
}
assert set(receipt['corrected_fields']) == fields
assert len(receipt['corrected_files']) == 540
assert receipt['sampling_reruns'] == receipt['evidence_reruns'] == receipt['chain_replays'] == 0

for entry in receipt['corrected_files']:
    path = Path(entry['path'])
    before_bytes = (original/path).read_bytes()
    after_bytes = (root/path).read_bytes()
    assert hashlib.sha256(before_bytes).hexdigest() == entry['before_sha256']
    assert hashlib.sha256(after_bytes).hexdigest() == entry['after_sha256']
    before = json.loads(before_bytes)
    after = json.loads(after_bytes)
    before_records = before['records'] if path.name == 'ANALYSIS-COMPLETE.json' else [before]
    after_records = after['records'] if path.name == 'ANALYSIS-COMPLETE.json' else [after]
    assert len(before_records) == len(after_records)
    for old, new in zip(before_records, after_records):
        assert len(old['movement']) == len(new['movement']) == 6
        for old_bin, new_bin in zip(old['movement'], new['movement']):
            assert old_bin.keys() == new_bin.keys()
            for field in fields:
                old_bin.pop(field, None)
                new_bin.pop(field, None)
    assert before == after, path

for relative, digest in receipt['input_sha256'].items():
    assert hashlib.sha256((root/relative).read_bytes()).hexdigest() == digest, relative
assert hashlib.sha256((root/'SOURCE_FREEZE.json').read_bytes()).hexdigest() == receipt['source_freeze_sha256']
assert hashlib.sha256((root/'EVALUATION_RELEASE.json').read_bytes()).hexdigest() == receipt['release_sha256']
report = {
    'passed': True, 'changed_derived_files': 540,
    'permitted_fields': sorted(fields), 'all_other_fields_unchanged': True,
    'unchanged_raw_inputs': len(receipt['input_sha256']),
    'correction_receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
    'audit_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(root/'coordinator-audits/CORRECTION_AUDIT.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
