"""Read-only compilation inspection of controller seams at a saved 4M state."""

import hashlib
import json
import os
from pathlib import Path
import pickle
import subprocess
import time

os.sched_setaffinity(0, {28})
os.environ.update(JAX_PLATFORMS='cpu', CUDA_VISIBLE_DEVICES='', JAX_ENABLE_X64='1',
                  OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')

import jax  # noqa: E402

from benchmarks.issue_312.allocation_observer import replay_work  # noqa: E402
from benchmarks.issue_312.online_sampler import (  # noqa: E402
    OnlineReflectionSampler, prepare_contours,
)
from benchmarks.issue_312.online_session import dispatch_parameters  # noqa: E402


root = Path('/largedata/albert/jaxns-reflection-online-20261029')
source = Path('/largedata/albert/git/jaxns-reflection-online-20261029')
checkpoint_path = root / 'evaluation/online/uniform/seed-60/state.pkl'
digest = hashlib.sha256(checkpoint_path.read_bytes()).hexdigest()
with checkpoint_path.open('rb') as stream:
    checkpoint = pickle.load(stream)
state = checkpoint.state
work = replay_work(state, None)
prepared = prepare_contours(state, work)
jax.block_until_ready(prepared)
sampler = OnlineReflectionSampler(checkpoint.kernel, checkpoint.controller.policy, prepared)
results = []
for name, function, arguments in (
    ('prepare_contours', prepare_contours, (state, work)),
    ('dispatch_parameters', dispatch_parameters, (sampler, state, work)),
):
    began = time.monotonic()
    lowered = function.lower(*arguments)
    compiled = lowered.compile()
    elapsed = time.monotonic() - began
    hlo = lowered.compiler_ir(dialect='hlo').as_hlo_text()
    path = root / f'COMPILER_{name}.hlo.txt'
    path.write_text(hlo)
    memory = compiled.memory_analysis()
    results.append(dict(
        function=name, lower_and_compile_seconds=elapsed,
        memory={field: int(getattr(memory, field)) for field in (
            'argument_size_in_bytes', 'output_size_in_bytes', 'temp_size_in_bytes',
            'alias_size_in_bytes', 'generated_code_size_in_bytes',
        )},
        hlo_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        hlo_bytes=path.stat().st_size,
    ))
assert hashlib.sha256(checkpoint_path.read_bytes()).hexdigest() == digest
receipt = dict(
    source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source,
                                          text=True).strip(),
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    backend=jax.default_backend(), cpu_affinity=sorted(os.sched_getaffinity(0)),
    capacity=state.samples.log_likelihoods.shape[0], width=work.seed_idx.shape[0],
    policy_shape=list(checkpoint.controller.policy.log_parameters.shape),
    policy_dtype=str(checkpoint.controller.policy.log_parameters.dtype),
    checkpoint_sha256=digest, checkpoint_unchanged=True,
    scientific_kernel_calls=0, compiler_observed=results,
    scope='Controller preparation/dispatch only; not a full-kernel runtime benchmark.',
)
(root / 'COMPILER_INSPECTION.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
