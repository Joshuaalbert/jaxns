"""Independent numerical support audit of h/T settings with the actual toy model."""
import os
os.sched_setaffinity(0, {70})
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'
os.environ['JAX_PLATFORMS'] = 'cpu'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['JAX_ENABLE_X64'] = '1'

import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import jax
from jax import numpy as jnp

ROOT = Path('/largedata/albert/git/jaxns-reflection-online-20261029')
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
from benchmarks.issue_312.reflection_sampler import reflection_trajectory
from benchmarks.issue_312.tuning_common import make_model
from jaxns.pytree import pytree_ravel

model = make_model()
_, unravel = pytree_ravel(model.sample_U(jax.random.PRNGKey(3122991)))
scale = float(np.float32(.05))
rng = np.random.default_rng(3122991)
base_gaps = np.repeat([.1, 5., 15., 40.], 32)
base_points = rng.uniform(size=(128, 18))
ball = rng.normal(size=(128, 15))
ball *= (np.sqrt(2*base_gaps)*rng.uniform(size=128)**(1/15)
         / np.linalg.norm(ball, axis=1))[:, None]
base_points[:, 0] = .5 + .3*np.sin(2*np.pi*base_points[:, 1]) + 1e-5*ball[:, 0]
base_points[:, 2:16] = .5 + scale*ball[:, 1:]
base_velocity = rng.normal(size=base_points.shape)
base_jitter = rng.uniform(.8, 1.2, size=128)
settings = [(h, t) for h in [1e-4, 2e-4, 5e-4, .001, .003, .01, .03]
            for t in [.003, .01, .03, .1, .3]]
points = np.tile(base_points, (len(settings), 1))
velocity = np.tile(base_velocity, (len(settings), 1))
gaps = np.tile(base_gaps, len(settings))
setting_idx = np.repeat(np.arange(len(settings)), 128)
requested_h = np.array([s[0] for s in settings])[setting_idx]
requested_t = np.array([s[1] for s in settings])[setting_idx]
durations = np.minimum(requested_t, 256*requested_h)
ratio = durations/requested_h
nearest = np.rint(ratio)
ratio = np.where(abs(ratio-nearest) <= 8*np.finfo(float).eps*np.maximum(1, abs(ratio)),
                 nearest, ratio)
bounces = np.ceil(ratio).astype(np.int32)
steps = durations/bounces*np.tile(base_jitter, len(settings))


def likelihood(point):
    return model.log_likelihood(unravel(point))


@jax.jit
@jax.vmap
def advance(point, direction, step, count):
    return reflection_trajectory(point, direction, step, count, jnp.asarray(-1.),
                                 jax.value_and_grad(likelihood))


q, v = map(np.asarray, jax.block_until_ready(advance(points, velocity, steps, bounces)))
qr, vr = map(np.asarray, jax.block_until_ready(advance(q, -v, steps, bounces)))


def drift(x, direction, dt):
    unfolded = np.remainder(x + dt[:, None]*direction, 2.)
    return 1.-np.abs(1.-unfolded), direction*np.where(unfolded < 1., 1., -1.)


x, direction = points.copy(), velocity.copy()
for iteration in range(int(bounces.max())):
    active = bounces > iteration
    old_x, old_direction = x, direction
    middle, incoming = drift(x, direction, steps/2)
    residual = middle[:, 0]-(.5+.3*np.sin(2*np.pi*middle[:, 1]))
    gradient = np.zeros_like(middle)
    gradient[:, 0] = -residual/(1e-5**2)
    gradient[:, 1] = residual/(1e-5**2)*.6*np.pi*np.cos(2*np.pi*middle[:, 1])
    gradient[:, 2:16] = -(middle[:, 2:16]-.5)/(scale**2)
    norm = np.linalg.norm(gradient, axis=1)
    normal = gradient/np.where(norm > 0., norm, 1.)[:, None]
    reflected = incoming-2*np.sum(incoming*normal, axis=1)[:, None]*normal
    next_x, next_direction = drift(middle, reflected, steps/2)
    x = np.where(active[:, None], next_x, old_x)
    direction = np.where(active[:, None], next_direction, old_direction)

peak = float(likelihood(jnp.full(18, .5)))
accept = np.asarray(jax.jit(jax.vmap(likelihood))(q)) > peak-gaps
position_error = np.max(abs(qr-points), axis=1)
velocity_error = np.max(abs(vr+velocity), axis=1)
np_position_error = np.max(abs(x-q), axis=1)
np_velocity_error = np.max(abs(direction-v), axis=1)
rows = []
for k, (h, t) in enumerate(settings):
    for gap in np.unique(gaps):
        selected = (setting_idx == k) & (gaps == gap)
        accepted = selected & accept
        rows.append(dict(
            desired_h=h, requested_T=t, B=int(bounces[selected][0]), gap=float(gap),
            T=float(durations[selected][0]), n=int(selected.sum()), accepted=int(accepted.sum()),
            pos=float(position_error[selected].max()), vel=float(velocity_error[selected].max()),
            np_pos=float(np_position_error[selected].max()),
            np_vel=float(np_velocity_error[selected].max()),
            accepted_pos=float(position_error[accepted].max(initial=0)),
            accepted_vel=float(velocity_error[accepted].max(initial=0)),
        ))
failed = [r for r in rows if r['pos'] >= 2e-9 or r['vel'] >= 2e-8
          or r['np_pos'] >= 2e-9 or r['np_vel'] >= 2e-8]
report = dict(
    paths=len(points), settings=len(settings), cases=len(rows), failed_cases=failed, rows=rows,
    model='unchanged normalized run_ridge.prior_model',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    maxima={name: float(values.max()) for name, values in [
        ('pos', position_error), ('vel', velocity_error),
        ('np_pos', np_position_error), ('np_vel', np_velocity_error),
    ]},
)
Path('/tmp/jaxns-online-range-probe-20261029.json').write_text(json.dumps(report, indent=2)+'\n')
np.savez_compressed(
    '/tmp/jaxns-online-range-probe-20261029.npz', points=points, velocity=velocity,
    bounces=bounces, steps=steps, gaps=gaps, durations=durations, setting_idx=setting_idx,
    endpoints=q, end_velocity=v, reversed_points=qr, reversed_velocity=vr,
    numpy_points=x, numpy_velocity=direction, accepted=accept,
)
print(json.dumps({k: value for k, value in report.items() if k != 'rows'}, indent=2))
