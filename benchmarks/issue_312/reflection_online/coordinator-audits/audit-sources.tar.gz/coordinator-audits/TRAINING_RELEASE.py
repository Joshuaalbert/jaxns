"""Coordinator release after independent smoke and numerical checks."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/largedata/albert/jaxns-reflection-online-20261029')
source = Path('/largedata/albert/git/jaxns-reflection-online-20261029')
freeze_path = root / 'SOURCE_FREEZE.json'
freeze = json.loads(freeze_path.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert freeze['source_commit'] == '47a9384388d67063f53170ba91ec702d1fc78077'
assert digest(freeze_path) == 'e684cbcabcb077f8765c25c44a61bf0b1d9914488d2ed3446cc972f5def4b949'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == freeze['source_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True)
for name, expected in freeze['source_sha256'].items():
    assert digest(source / name) == expected, name
audit_path = Path('/tmp/jaxns-online-independent-smoke-audit-20261029.json')
audit = json.loads(audit_path.read_text())
assert audit['passed'] and audit['runs'] == 2
smokes = {}
for allocation in ('uniform', 'evidence_improving'):
    folder = root / 'smoke-47a9384' / allocation
    result = json.loads((folder / 'ANALYSIS-COMPLETE.json').read_text())
    controller = json.loads((folder / 'CONTROLLER-AUDIT.json').read_text())
    assert result['passed'] and result['evidence_complete'] and controller['passed']
    assert json.loads((folder / 'CORE-300000.json').read_text())['controller_real_updates'] > 0
    smokes[allocation] = {name: digest(folder / name) for name in (
        'ANALYSIS-COMPLETE.json', 'CONTROLLER-AUDIT.json', 'CORE-300000.json')}
release = dict(
    approved=True, source_commit=freeze['source_commit'],
    protocol_sha256=freeze['protocol_sha256'], source_freeze_sha256=digest(freeze_path),
    coordinator='root', phase='training', training_seeds=list(range(3122910, 3122914)),
    allocations=['uniform', 'evidence_improving'], budgets=[2000000, 4000000],
    independent_smoke_audit_sha256=digest(audit_path), smoke_receipts=smokes,
    numerical_probe_sha256=digest(Path('/tmp/jaxns-online-stable-range-probe-20261029.json')),
    review='review03 bounds; unchanged integrator and numerical tolerances; 44 focused tests; independent chronological audit and all-chain replay passed. Evaluation remains unreleased.',
)
path = root / 'TRAINING_RELEASE.json'
with path.open('x') as handle:
    handle.write(json.dumps(release, indent=2) + '\n')
print(json.dumps(dict(path=str(path), sha256=digest(path), approved=True)))
