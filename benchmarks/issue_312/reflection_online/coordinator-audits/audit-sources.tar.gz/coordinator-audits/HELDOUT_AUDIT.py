"""Independent NumPy policy construction and held-out distribution checks."""
import os
os.sched_setaffinity(0, {70})
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'

import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.special import betainc
from scipy.stats import kstest, ks_2samp

ROOT = Path('/largedata/albert/jaxns-reflection-online-20261029')
GRID = np.arange(65)*2.
INITIAL = np.log([.003, .03])


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def volume(values, parents):
    contours, inverse, sizes = np.unique(values, return_inverse=True, return_counts=True)
    descendants = np.bincount(parents[parents >= 0], minlength=len(values))
    outgoing = np.bincount(inverse, weights=descendants).astype(np.int64)
    incoming = int((parents < 0).sum()) + np.r_[0, np.cumsum(outgoing-sizes)[:-1]]
    gt = incoming-sizes+1.
    return contours, -np.cumsum(np.log(gt/(gt+np.where(sizes == 1, 1., sizes+1.))))


def check_policies():
    results = []
    for allocation in ('uniform', 'evidence_improving'):
        profiles, all_knots = [], []
        for seed in range(3122910, 3122914):
            folder = ROOT/'training'/'online'/allocation/f'seed-{seed}'
            with np.load(folder/'calls-4000000.npz') as data:
                contours, compression = volume(data['log_likelihood'], data['parent_indices'])
            with np.load(folder/'policies-4000000.npz') as data:
                logs = data['log_parameters'][-1]
            profiles.append((contours, compression, logs))
            all_knots.extend(np.interp(GRID, compression, contours))
            all_knots.extend(contours[[0, -1]])
        knots = np.unique(all_knots)
        predictions = []
        for contours, compression, logs in profiles:
            indices = np.searchsorted(contours, knots, side='right')-1
            c = np.where(indices >= 0, compression[np.maximum(indices, 0)], 0.)
            predictions.append(np.column_stack([np.interp(c, GRID, logs[:, d]) for d in range(2)]))
        expected = np.mean(predictions, axis=0)
        path = ROOT/'frozen'/f'{allocation}.json'
        policy = json.loads(path.read_text())
        assert policy['coordinate'] == 'parent_log_likelihood'
        assert policy['training_seeds'] == list(range(3122910, 3122914))
        assert policy['tail_policy'] == 'constant'
        np.testing.assert_allclose(policy['contours'], knots, rtol=2e-12, atol=2e-12)
        np.testing.assert_allclose(policy['log_parameters'], expected, rtol=2e-12, atol=2e-12)
        results.append(dict(allocation=allocation, knots=len(knots), sha256=digest(path), passed=True))
    return results


def parameters(policy, contour, choices):
    if policy is None:
        logs = INITIAL
        np.testing.assert_array_equal(choices, 0)
    else:
        logs = np.array([np.interp(contour, policy['contours'],
                                  np.asarray(policy['log_parameters'])[:, d]) for d in range(2)])
    base = np.where(logs == INITIAL, [.003, .03], np.exp(logs))
    factors = np.array([[1, 1], [1/1.5, 1], [1.5, 1], [1, 1/1.5], [1, 1.5]])
    bounded = np.clip(base*factors[choices], [.001, .003], [.03, .1])
    ratio = bounded[:, 1]/bounded[:, 0]
    nearest = np.rint(ratio)
    ratio = np.where(abs(ratio-nearest) <= 8*np.finfo(float).eps*np.maximum(1, abs(ratio)), nearest, ratio)
    count = np.ceil(ratio).astype(np.int64)
    step = np.where((bounded[:, 1] == .03) & (count == 10), .003, bounded[:, 1]/count)
    return count, step


def check_heldout():
    path = ROOT/'validation'/'VALIDATION.json'
    validation = json.loads(path.read_text())
    peak = json.loads((ROOT/'smoke-47a9384'/'uniform'/'MANIFEST.json').read_text())['peak']
    assert validation['passed'] and len(validation['records']) == 21
    assert validation['source_freeze_sha256'] == digest(ROOT/'SOURCE_FREEZE.json')
    policies = {allocation: json.loads((ROOT/'frozen'/f'{allocation}.json').read_text())
                for allocation in ('uniform', 'evidence_improving')}
    for allocation in policies:
        assert validation['frozen_policy_sha256'][allocation] == digest(ROOT/'frozen'/f'{allocation}.json')
    def residual(x):
        return np.column_stack([(x[:, 0]-.5-.3*np.sin(2*np.pi*x[:, 1]))/1e-5,
                                (x[:, 2:16]-.5)/float(np.float32(.05))])
    seen, records = set(), []
    for record in validation['records']:
        case, arm = record['case'], record['arm']
        assert (case, arm) not in seen
        seen.add((case, arm))
        gap = np.inf if record['gap'] == 'infinity' else record['gap']
        archive = ROOT/'validation'/f'case-{case}-{arm}.npz'
        assert digest(archive) == record['archive_sha256']
        with np.load(archive) as arrays:
            data = dict(arrays)
        initial = data['initial']
        n = len(initial)
        assert n == 8192 and initial.shape == (n, 18)
        policy = None if arm == 'fixed' else policies[arm.removeprefix('frozen_')]
        # Use the recorded production peak, whose TFP scalar precision is preserved.
        contour = peak-gap
        b, h = parameters(policy, contour, data['path_choices'])
        chain_b, chain_h = parameters(policy, contour, data['chain_choices'])
        np.testing.assert_array_equal(data['bounce_counts'], b)
        np.testing.assert_array_equal(data['chain_bounce_counts'], chain_b)
        np.testing.assert_allclose(data['nominal_steps'], h, rtol=2e-14, atol=0)
        np.testing.assert_allclose(data['chain_nominal_steps'], chain_h, rtol=2e-14, atol=0)
        np.testing.assert_array_equal(data['path_gradients'], b)
        np.testing.assert_array_equal(data['gradients'], 9*chain_b)
        np.testing.assert_array_equal(data['value_only_evaluations'], data['evaluations']-data['gradients'])
        np.testing.assert_array_equal(data['accepted'], np.isfinite(data['proposed_log_likelihood']) &
                                      (data['proposed_log_likelihood'] > contour))
        np.testing.assert_array_equal(data['path_points'][~data['accepted']], initial[~data['accepted']])
        np.testing.assert_array_equal(data['path_points'][data['accepted']], data['proposed_points'][data['accepted']])
        np.testing.assert_allclose(data['realised_durations'], data['realised_steps']*b, rtol=0, atol=0)
        np.testing.assert_allclose(data['chain_realised_durations'], data['chain_realised_steps']*chain_b[:, None], rtol=0, atol=0)
        assert np.all(data['realised_steps'] >= .8*h*(1-1e-14))
        assert np.all(data['realised_steps'] <= 1.2*h*(1+1e-14))
        np.testing.assert_array_equal(data['final_points'], data['cycle_points'][:, -1])
        for law, field in (('single_path', 'path_points'), ('full_chain', 'final_points')):
            x = data[field]
            assert x.shape == (n, 18) and x.dtype == np.float64
            assert np.all((x >= 0) & (x <= 1))
            assert np.all(np.sum(residual(x)**2, axis=1) < 2*gap)
            if gap < 50:
                u = np.column_stack([x[:, [1, 16, 17]],
                                     betainc(8, 8, (residual(x)/np.sqrt(2*gap)+1)/2),
                                     (np.sum(residual(x)**2, axis=1)/(2*gap))**7.5])
                ks = [float(kstest(v, 'uniform').statistic) for v in u.T]
                limit = 5/np.sqrt(n)
            elif np.isposinf(gap):
                ks = [float(kstest(v, 'uniform').statistic) for v in x.T]
                limit = 5/np.sqrt(n)
            else:
                ref = data['independent_reference']
                left = np.column_stack([x, residual(x), np.linalg.norm(residual(x), axis=1)])
                right = np.column_stack([ref, residual(ref), np.linalg.norm(residual(ref), axis=1)])
                ks = [float(ks_2samp(a, b).statistic) for a, b in zip(left.T, right.T, strict=True)]
                limit = 5*np.sqrt(2/n)
            np.testing.assert_allclose(ks, record['stationarity'][law]['ks'], rtol=0, atol=2e-14)
            np.testing.assert_allclose(limit, record['stationarity'][law]['limit'], rtol=0, atol=1e-15)
            assert max(ks) < limit
        records.append(dict(case=case, arm=arm, passed=True))
    assert seen == {(case, arm) for case in range(7) for arm in ('fixed', 'frozen_uniform', 'frozen_evidence_improving')}
    return dict(records=records, validation_sha256=digest(path), passed=True)


parser = argparse.ArgumentParser()
parser.add_argument('--heldout', action='store_true')
parser.add_argument('--output', type=Path, required=True)
options = parser.parse_args()
result = dict(passed=True, policies=check_policies(), source_sha256=digest(Path(__file__)))
if options.heldout:
    result['heldout'] = check_heldout()
options.output.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: value for key, value in result.items() if key != 'heldout'}, indent=2))
