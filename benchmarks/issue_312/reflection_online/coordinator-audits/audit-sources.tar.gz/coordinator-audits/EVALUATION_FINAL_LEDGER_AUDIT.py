"""Coordinator audit of raw histories without importing the controller implementation."""
import os
os.sched_setaffinity(0, {70})
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'

import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np


GRID = np.arange(65, dtype=float)*2
INITIAL = np.log([.003, .03])


def check_close(left, right):
    np.testing.assert_allclose(left, right, rtol=2e-12, atol=2e-12, equal_nan=True)


def table_from_anchors(anchors, learned):
    indices = np.flatnonzero(learned)
    if not len(indices):
        return np.tile(INITIAL, (65, 1)), np.full(2, np.nan)
    positions = 2*indices+1
    values = anchors[indices]
    result = np.column_stack([np.interp(GRID, positions, values[:, d]) for d in range(2)])
    if len(indices) > 1:
        left_slope = np.clip((values[1]-values[0])/(positions[1]-positions[0]),
                             -np.log(1.25), np.log(1.25))
        right_slope = np.clip((values[-1]-values[-2])/(positions[-1]-positions[-2]),
                              -np.log(1.25), np.log(1.25))
        low, high = GRID < positions[0], GRID > positions[-1]
        result[low] = values[0] + np.maximum(GRID[low]-positions[0], -2)[:, None]*left_slope
        result[high] = values[-1] + np.minimum(GRID[high]-positions[-1], 2)[:, None]*right_slope
    return result, positions[[0, -1]]


def prior_volume(values, parents):
    child = parents >= 0
    unique, inverse, sizes = np.unique(values, return_inverse=True, return_counts=True)
    outgoing_per_row = np.bincount(parents[child], minlength=len(values))
    outgoing = np.bincount(inverse, weights=outgoing_per_row).astype(np.int64)
    incoming = int((~child).sum()) + np.r_[0, np.cumsum(outgoing-sizes)[:-1]]
    assert np.all(incoming >= sizes)
    beyond = incoming-sizes+1.
    # Singleton races are Beta(K,1); only genuine plateaus have an equality atom.
    denominator = beyond + np.where(sizes == 1, 1., sizes+1.)
    return unique, -np.cumsum(np.log(beyond/denominator)), incoming


def audit_run(folder):
    manifest = json.loads((folder/'MANIFEST.json').read_text())
    assert manifest['comparison'] == 'online' and manifest['record_schema'] == 3
    budget = manifest['budgets'][-1]
    core = json.loads((folder/f'CORE-{budget}.json').read_text())
    archive = folder/f'calls-{budget}.npz'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == core['archive_sha256']
    with np.load(archive) as data:
        raw = dict(data)
    with np.load(folder/f'controller-{budget}.npz') as data:
        ledger = dict(data)
    with np.load(folder/f'policies-{budget}.npz') as data:
        policies = dict(data)
    receipts = [json.loads(line) for line in (folder/'controller-history.jsonl').read_text().splitlines()]
    n = len(raw['samples'])
    root = raw['seed_indices'] < 0
    assert n == core['samples'] and root.sum() == core['roots']
    assert np.all(raw['log_likelihood'] > raw['log_L_constraints'])
    assert np.all((raw['unit_samples'] >= 0) & (raw['unit_samples'] <= 1))
    assert raw['unit_samples'].dtype == np.float64
    ids = np.arange(n)[~root]
    seeds = raw['seed_indices'][~root]
    assert np.all(seeds < ids)
    assert np.all(raw['log_L_constraints'][seeds] <= raw['log_L_constraints'][~root])
    assert np.all(raw['log_likelihood'][seeds] > raw['log_L_constraints'][~root])
    np.testing.assert_array_equal(raw['gradient_evaluations_per_sample'], 9*raw['bounce_counts'])
    assert np.all(raw['bounce_counts'][root] == 0)
    assert np.all(raw['evaluations_per_sample'][root] == 1)
    assert int(raw['evaluations_per_sample'].sum()) == core['evaluations']
    assert core['evaluations_before_last_batch'] < budget <= core['evaluations']
    assert np.all(raw['evaluations_per_sample'][~root] >= 9*raw['bounce_counts'][~root]+18)
    np.testing.assert_array_equal(ledger['sample_indices'], np.arange(150, n))
    np.testing.assert_array_equal(ledger['work'], raw['evaluations_per_sample'][150:])
    np.testing.assert_array_equal(ledger['num_bounces'], raw['bounce_counts'][150:])
    check_close(ledger['step_size'], raw['nominal_steps'][150:])

    counts = np.zeros((64, 5), dtype=np.int64)
    jumps = np.zeros((64, 5))
    costs = np.zeros((64, 5), dtype=np.int64)
    exposure = np.zeros(64)
    total_exposure = np.zeros(64)
    generations = np.zeros(64, dtype=np.int64)
    anchors, learned = np.zeros((64, 2)), np.zeros(64, dtype=bool)
    table, support = table_from_anchors(anchors, learned)
    version, next_row, real_updates = 0, 150, 0
    for receipt in receipts:
        start, stop = receipt['start'], receipt['stop']
        assert start == next_row and start < stop <= n
        rows = slice(start-150, stop-150)
        child = raw['seed_indices'][start:stop] >= 0
        levels, compression, incoming = prior_volume(raw['log_likelihood'][:start],
                                                     raw['parent_indices'][:start])
        positions = np.searchsorted(levels, raw['log_L_constraints'][start:stop], side='right')-1
        expected_c = np.where(positions >= 0, compression[np.maximum(positions, 0)], 0.)
        expected_k = np.where(positions >= 0, incoming[np.maximum(positions, 0)],
                              (raw['parent_indices'][:start] < 0).sum())
        check_close(ledger['compression'][rows], expected_c)
        np.testing.assert_array_equal(ledger['incoming_k'][rows], expected_k)
        check_close(policies['log_parameters'][version], table)
        check_close(policies['support'][version], support)
        assert receipt['dispatch_version'] == version
        np.testing.assert_array_equal(ledger['controller_versions'][rows], version)
        if manifest['arm'] != 'frozen':
            c = np.clip(ledger['compression'][rows][child], 0, 128)
            logs = np.column_stack([np.interp(c, GRID, table[:, d]) for d in range(2)])
            base = np.where(logs == INITIAL, [.003, .03], np.exp(logs))
            factors = np.array([[1, 1], [1/1.5, 1], [1.5, 1], [1, 1/1.5], [1, 1.5]])
            setting = ledger['choice'][rows][child]
            desired = base*factors[setting]
            bounded = np.clip(desired, [.001, .003], [.03, .1])
            duration = np.minimum(bounded[:, 1], 256*bounded[:, 0])
            ratio = duration/bounded[:, 0]
            nearest = np.rint(ratio)
            ratio = np.where(abs(ratio-nearest) <= 8*np.finfo(float).eps*np.maximum(1, abs(ratio)),
                             nearest, ratio)
            b = np.clip(np.ceil(ratio), 1, 256).astype(int)
            h = np.where((duration == .03) & (b == 10), .003, duration/b)
            np.testing.assert_array_equal(ledger['num_bounces'][rows][child], b)
            check_close(ledger['step_size'][rows][child], h)
            check_close(ledger['nominal_duration'][rows][child], duration)
            check_close(ledger['requested_step'][rows][child], desired[:, 0])
            check_close(ledger['requested_duration'][rows][child], desired[:, 1])
            if manifest['arm'] == 'fixed':
                np.testing.assert_array_equal(setting, 0)
        strata_all = np.clip(np.floor(ledger['compression'][rows]/2).astype(np.int64), 0, 63)
        np.testing.assert_array_equal(ledger['controller_generations'][rows], generations[strata_all])
        starts = raw['unit_samples'][np.maximum(raw['seed_indices'][start:stop], 0)]
        squared = np.sum((raw['unit_samples'][start:stop]-starts)**2, axis=1)
        check_close(ledger['squared_jumps'][rows], np.where(child, squared, 0.))
        strata = strata_all[child]
        choices = ledger['choice'][rows][child]
        np.add.at(counts, (strata, choices), 1)
        np.add.at(jumps, (strata, choices), ledger['squared_jumps'][rows][child])
        np.add.at(costs, (strata, choices), ledger['work'][rows][child])
        increments = np.log1p(1/ledger['incoming_k'][rows][child])
        np.add.at(exposure, strata, increments)
        np.add.at(total_exposure, strata, increments)
        expected_changed = []
        if manifest['arm'] == 'online':
            for j in np.flatnonzero((exposure >= 1) & (counts[:, 0] >= 64)):
                eligible = [d for d, (a, b) in enumerate(((1, 2), (3, 4)))
                            if min(counts[j, a], counts[j, b]) >= 8]
                if not eligible:
                    continue
                old = np.array([np.interp(2*j+1, GRID, table[:, d]) for d in range(2)])
                proposed = old.copy()
                for d in eligible:
                    minus, plus = ((1, 2), (3, 4))[d]
                    q_minus, q_plus = jumps[j, minus]/costs[j, minus], jumps[j, plus]/costs[j, plus]
                    contrast = (q_plus-q_minus)/(q_plus+q_minus) if q_plus+q_minus else 0.
                    proposed[d] += np.log(1.25)*contrast
                change = receipt['changes'][len(expected_changed)]
                assert change['stratum'] == j and change['dimensions'] == eligible
                check_close(change['previous'], old)
                check_close(change['proposed'], proposed)
                check_close(change['jumps'], jumps[j])
                np.testing.assert_array_equal(change['counts'], counts[j])
                np.testing.assert_array_equal(change['work'], costs[j])
                check_close(change['exposure'], exposure[j])
                anchors[j], learned[j] = proposed, True
                expected_changed.append(j)
        assert len(expected_changed) == len(receipt['changes'])
        if expected_changed:
            new_table, support = table_from_anchors(anchors, learned)
            changed = np.any(new_table != table, axis=1)
            reset = changed[:-1] | changed[1:]
            reset[expected_changed] = True
            np.testing.assert_array_equal(receipt['reset_strata'], np.flatnonzero(reset))
            counts[reset], jumps[reset], costs[reset], exposure[reset] = 0, 0., 0, 0.
            generations[reset] += 1
            real_updates += int(np.any(changed))
            table = new_table
            version += 1
        assert receipt['next_version'] == version
        next_row = stop
    assert next_row == n and version == int(policies['version'][-1])
    assert version == core['controller_version'] and real_updates == core['controller_real_updates']
    check_close(policies['log_parameters'][-1], table)
    probability = np.exp(raw['log_weights']-np.max(raw['log_weights']))
    probability /= probability.sum()
    mean = probability @ raw['samples']
    std = np.sqrt(probability @ (raw['samples']-mean)**2)
    check_close(core['mean'], mean)
    check_close(core['std'], std)
    return dict(folder=str(folder), phase=manifest['phase'], arm=manifest['arm'],
                allocation=manifest['allocation'], seed=manifest['seed'], samples=n,
                evaluations=core['evaluations'], versions=version, real_updates=real_updates,
                batches=len(receipts), passed=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('--phase', choices=('training', 'evaluation', 'smoke'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    options = parser.parse_args()
    began = time.monotonic()
    rows = []
    for manifest_path in sorted(options.root.rglob('MANIFEST.json')):
        manifest = json.loads(manifest_path.read_text())
        if manifest.get('comparison') != 'online' or manifest.get('phase') != options.phase:
            continue
        if not (manifest_path.parent/'COMPLETE.json').exists():
            continue
        rows.append(audit_run(manifest_path.parent))
    if not rows:
        raise ValueError('No completed requested-phase runs were found.')
    result = dict(passed=True, phase=options.phase, runs=len(rows), records=rows,
                  seconds=time.monotonic()-began,
                  audit_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    options.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))


if __name__ == '__main__':
    main()
