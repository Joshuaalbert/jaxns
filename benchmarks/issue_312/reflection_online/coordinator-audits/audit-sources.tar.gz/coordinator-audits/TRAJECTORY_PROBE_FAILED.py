"""Independent NumPy phase-map and heterogeneous JAX-loop comparison."""
import os
os.sched_setaffinity(0, {70})
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'
os.environ['JAX_PLATFORMS'] = 'cpu'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['JAX_ENABLE_X64'] = '1'
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import jax
from jax import numpy as jnp
sys.path[:0] = ['/largedata/albert/git/jaxns-reflection-online-20261029',
                '/largedata/albert/git/jaxns-reflection-online-20261029/src']
from benchmarks.issue_312.reflection_sampler import reflection_trajectory
jax.config.update('jax_enable_x64', True)
assert jax.default_backend() == 'cpu'
scale = float(np.float32(.05))
rng = np.random.default_rng(3122990)
gaps = np.tile(np.repeat([.1, 5., 15., 40.], 16), 6)
bounces = np.repeat([1, 2, 10, 37, 128, 256], 64).astype(np.int32)
durations = np.repeat([.003, .03, .3, .06, .03, .00256], 64)
points = rng.uniform(size=(384, 18))
ball = rng.normal(size=(384, 15))
ball *= (np.sqrt(2*gaps)*rng.uniform(size=384)**(1/15) / np.linalg.norm(ball, axis=1))[:,None]
points[:,0] = .5 + .3*np.sin(2*np.pi*points[:,1]) + 1e-5*ball[:,0]
points[:,2:16] = .5 + scale*ball[:,1:]
velocity = rng.normal(size=points.shape)
steps = durations/bounces * rng.uniform(.8, 1.2, size=384)

def likelihood(point):
    residual = point[0]-.5-.3*jnp.sin(2*jnp.pi*point[1])
    return -.5*((residual/1e-5)**2 + jnp.sum(((point[2:16]-.5)/scale)**2))

@jax.jit
@jax.vmap
def advance(point, direction, step, count):
    return reflection_trajectory(point, direction, step, count, jnp.asarray(-1.),
                                 jax.value_and_grad(likelihood))

q, v = map(np.asarray, jax.block_until_ready(advance(points, velocity, steps, bounces)))
qr, vr = map(np.asarray, jax.block_until_ready(advance(q, -v, steps, bounces)))

# Independent vectorized NumPy phase map, with explicit active-lane selection.
def drift(x, direction, dt):
    unfolded = np.remainder(x + dt[:,None]*direction, 2.)
    return 1.-np.abs(1.-unfolded), direction*np.where(unfolded < 1., 1., -1.)

x, direction = points.copy(), velocity.copy()
for iteration in range(int(bounces.max())):
    active = bounces > iteration
    old_x, old_direction = x, direction
    middle, incoming = drift(x, direction, steps/2)
    residual = middle[:,0]-.5-.3*np.sin(2*np.pi*middle[:,1])
    gradient = np.zeros_like(middle)
    gradient[:,0] = -residual/(1e-5**2)
    gradient[:,1] = residual/(1e-5**2) * .6*np.pi*np.cos(2*np.pi*middle[:,1])
    gradient[:,2:16] = -(middle[:,2:16]-.5)/(scale**2)
    norm = np.linalg.norm(gradient, axis=1)
    normal = gradient/np.where(norm > 0., norm, 1.)[:,None]
    reflected = incoming-2*np.sum(incoming*normal, axis=1)[:,None]*normal
    next_x, next_direction = drift(middle, reflected, steps/2)
    x = np.where(active[:,None], next_x, old_x)
    direction = np.where(active[:,None], next_direction, old_direction)

report = {
    'cpu_only': True, 'paths': 384, 'bounces': [1,2,10,37,128,256],
    'nominal_durations': [.003,.03,.3,.06,.03,.00256],
    'reversal_position_max': float(np.max(abs(qr-points))),
    'reversal_velocity_max': float(np.max(abs(vr+velocity))),
    'numpy_jax_position_max': float(np.max(abs(x-q))),
    'numpy_jax_velocity_max': float(np.max(abs(direction-v))),
    'speed_squared_error_max': float(np.max(abs(np.sum(v*v,axis=1)-np.sum(velocity*velocity,axis=1)))),
    'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
print(json.dumps(report, indent=2))
Path('/tmp/jaxns-online-independent-trajectory-probe-20261029.json').write_text(json.dumps(report,indent=2)+'\n')
# Original frozen numerical reversal tolerances, without relaxation.
assert report['reversal_position_max'] < 2e-9
assert report['reversal_velocity_max'] < 2e-8
assert report['numpy_jax_position_max'] < 2e-9
assert report['numpy_jax_velocity_max'] < 2e-8
assert report['speed_squared_error_max'] < 1e-10
