"""Bind the evaluation cohort to reviewed sources, training and validation."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/largedata/albert/jaxns-reflection-online-20261029')
source = Path('/largedata/albert/git/jaxns-reflection-online-20261029')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
freeze = json.loads((root/'SOURCE_FREEZE.json').read_text())
ready = json.loads((root/'EVALUATION_READINESS.json').read_text())
training_path = Path('/tmp/jaxns-online-independent-training-audit-20261029.json')
heldout_path = Path('/tmp/jaxns-online-independent-heldout-audit-20261029.json')
training, heldout = [json.loads(path.read_text()) for path in (training_path, heldout_path)]
assert training['passed'] and training['runs'] == 8
assert heldout['passed'] and heldout['heldout']['passed']
assert len(heldout['heldout']['records']) == 21
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == freeze['source_commit']
for name, expected in freeze['source_sha256'].items():
    assert digest(source/name) == expected, name
assert ready['source_freeze_sha256'] == digest(root/'SOURCE_FREEZE.json')
assert ready['validation_sha256'] == digest(root/'validation/VALIDATION.json')
assert ready['validation_sha256'] == heldout['heldout']['validation_sha256']
for allocation, expected in ready['frozen_policy_sha256'].items():
    assert expected == digest(root/'frozen'/f'{allocation}.json')
release = dict(
    approved=True, coordinator='root', phase='evaluation',
    source_commit=freeze['source_commit'], protocol_sha256=freeze['protocol_sha256'],
    source_freeze_sha256=digest(root/'SOURCE_FREEZE.json'),
    validation_sha256=ready['validation_sha256'],
    frozen_policy_sha256=ready['frozen_policy_sha256'],
    independent_training_audit_sha256=digest(training_path),
    independent_heldout_audit_sha256=digest(heldout_path),
    seeds=list(range(60, 90)), arms=['fixed', 'online', 'frozen'],
    allocations=['uniform', 'evidence_improving'], budgets=[2000000, 4000000],
    cpu_only=True, maximum_workers=24, all_runs_and_failures_retained=True,
    review='Independent training history, frozen-policy construction and all21 held-out ensembles pass. Source/integrator unchanged. Online adaptation remains experimental; frozen-kernel checks do not prove adaptive stationarity.',
)
path = root/'EVALUATION_RELEASE.json'
with path.open('x') as handle:
    handle.write(json.dumps(release, indent=2)+'\n')
print(json.dumps(dict(path=str(path), sha256=digest(path), approved=True)))
