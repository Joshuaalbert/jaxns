"""Independent raw-draw, posterior and paired-bootstrap aggregate cross-check.

This script does not import the experiment's reducer or reporting functions.
The separate coordinator ledger audit verifies chronological sampling history.
"""

import hashlib
import json
import os
from pathlib import Path
import time

os.sched_setaffinity(0, {28})
for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[variable] = '1'

import numpy as np  # noqa: E402
from scipy.special import logsumexp, ndtr, ndtri  # noqa: E402


def close(actual, expected):
    np.testing.assert_allclose(actual, expected, rtol=2e-12, atol=2e-12)


def discrete_w1(points, weights, target):
    """Integrate the two step CDFs, independently of scipy Wasserstein code."""
    order = np.argsort(points)
    x = points[order]
    probability = np.r_[0., np.cumsum(weights[order])]
    union = np.unique(np.r_[x, target])
    left = union[:-1]
    first = probability[np.searchsorted(x, left, side='right')]
    second = np.searchsorted(target, left, side='right') / len(target)
    return np.sum(abs(first-second) * np.diff(union))


root = Path('/largedata/albert/jaxns-reflection-online-20261029')
started = time.monotonic()
summary_path = root / 'SUMMARY.json'
summary_hash = hashlib.sha256(summary_path.read_bytes()).hexdigest()
summary = json.loads(summary_path.read_text())
indices = np.random.default_rng(3122903).integers(0, 30, (100000, 30))
quantiles = (np.arange(8192)+.5)/8192
initials, groups, boots, records = {}, {}, {}, []
for arm in ('fixed', 'online', 'frozen'):
    for allocation in ('uniform', 'evidence_improving'):
        for budget in (2000000, 4000000):
            rows = []
            for seed in range(60, 90):
                folder = root / 'evaluation' / arm / allocation / f'seed-{seed}'
                row = json.loads((folder / f'ANALYSIS-{budget}.json').read_text())
                assert (row['arm'], row['allocation'], row['seed'], row['budget']) == (
                    arm, allocation, seed, budget)
                assert row['mc_draws'] == 4096 and row['audit_passed'] and row['replay_exact']
                with np.load(folder / f'evidence-{budget}.npz') as evidence:
                    for estimator in ('classic_mc', 'phantom'):
                        draws = evidence[estimator + '_log_Z_samples']
                        assert draws.shape == (4096,) and np.isfinite(draws).all()
                        close(draws.mean(), row[estimator + '_log_Z'])
                        close(draws.std(), row[estimator + '_log_Z_uncert'])
                        close(draws.std(ddof=1)/64, row[estimator + '_mcse'])
                        close(np.quantile(draws, [.025, .975]), row[estimator + '_percentile95'])
                with np.load(folder / f'calls-{budget}.npz') as raw:
                    weights = np.exp(raw['log_weights'] - logsumexp(raw['log_weights']))
                    points = raw['samples']
                    mean = weights @ points
                    std = np.sqrt(weights @ ((points-mean)**2))
                    close(mean, row['mean'])
                    close(std, row['std'])
                    close(1/np.sum(weights**2), row['kish_ess'])
                    np.testing.assert_array_equal(raw['gradient_evaluations_per_sample'],
                                                  9 * raw['bounce_counts'])
                    child = raw['seed_indices'] >= 0
                    assert np.all(raw['evaluations_per_sample'][~child] == 1)
                    assert np.all(raw['bounce_counts'][~child] == 0)
                    assert raw['evaluations_per_sample'].sum() == row['evaluations']
                    np.testing.assert_array_equal(
                        raw['unit_samples'][:150],
                        initials.setdefault(seed, raw['unit_samples'][:150].copy()))
                    for coordinate in (1, 16, 17, 5):
                        values = points[:, coordinate]
                        order = np.argsort(values)
                        cdf = np.cumsum(weights[order])
                        truth = ndtr((values[order]-.5)/.05) if coordinate == 5 else values[order]
                        error = np.max(np.maximum(abs(cdf-truth),
                                                  abs(cdf-weights[order]-truth)))
                        target = .5+.05*ndtri(quantiles) if coordinate == 5 else quantiles
                        close(error, row[f'cdf_error_x{coordinate}'])
                        close(discrete_w1(values, weights, target), row[f'w1_x{coordinate}'])
                rows.append(row)
                records.append(dict(arm=arm, allocation=allocation, seed=seed, budget=budget,
                                    analysis_sha256=hashlib.sha256(
                                        (folder/f'ANALYSIS-{budget}.json').read_bytes()).hexdigest()))
            key = f'{arm}_{allocation}_{budget}'
            groups[key] = rows
            for estimator in ('classic_moments', 'classic_mc', 'phantom'):
                prefix = '' if estimator == 'classic_moments' else estimator+'_'
                errors = np.array([row[prefix+'log_Z'] for row in rows])
                sd = np.array([row[prefix+'log_Z_uncert'] for row in rows])
                boot = np.sqrt(np.mean(errors[indices]**2, axis=1))
                boots[key, estimator] = boot
                cell = summary['cells'][key]['estimators'][estimator]
                close(errors, cell['errors'])
                close(sd, cell['reported_sd'])
                close(errors.mean(), cell['bias'])
                close(errors.std(ddof=1), cell['error_sd'])
                close(np.sqrt(np.mean(errors**2)), cell['rmse'])
                close(boot.std(ddof=1), cell['rmse_bootstrap_se'])
                close(np.quantile(boot, [.025, .975]), cell['rmse_bootstrap95'])
                assert int(np.sum(abs(errors) <= 1.959963984540054*sd)) == cell['coverage95_count']
                if estimator != 'classic_moments':
                    covered = sum(row[prefix+'percentile95'][0] <= 0 <=
                                  row[prefix+'percentile95'][1] for row in rows)
                    assert covered == cell['mc_percentile_coverage95_count']

contrasts = 0
for allocation in ('uniform', 'evidence_improving'):
    for budget in (2000000, 4000000):
        for left, right in (('online', 'fixed'), ('frozen', 'fixed'), ('online', 'frozen')):
            for estimator in ('classic_moments', 'classic_mc', 'phantom'):
                first, second = f'{left}_{allocation}_{budget}', f'{right}_{allocation}_{budget}'
                item = summary['contrasts'][f'{left}_minus_{right}_{allocation}_{budget}_{estimator}']
                differences = boots[first, estimator] - boots[second, estimator]
                close(np.quantile(differences, [.025, .975]), item['paired_bootstrap95'])
                close(differences.std(ddof=1), item['paired_bootstrap_se'])
                contrasts += 1
        for arm in ('fixed', 'online', 'frozen'):
            key = f'{arm}_{allocation}_{budget}'
            item = summary['contrasts']['phantom_minus_classic_mc_'+key]
            differences = boots[key, 'phantom'] - boots[key, 'classic_mc']
            close(np.quantile(differences, [.025, .975]), item['paired_bootstrap95'])
            contrasts += 1

assert len(records) == 360 and contrasts == 48
assert hashlib.sha256(summary_path.read_bytes()).hexdigest() == summary_hash
result = dict(
    passed=True, snapshots=360, runs=180, paired_contrasts=48,
    bootstrap_draws=100000, bootstrap_seed=3122903,
    bootstrap_indices_sha256=hashlib.sha256(indices.tobytes()).hexdigest(),
    summary_sha256=summary_hash, raw_evidence_means_sds_mcse_and_intervals=True,
    raw_posterior_mean_sd_ess_cdf_and_discrete_reference_w1=True,
    exact_shared_initial_populations=True, raw_gradient_and_root_counts=True,
    seconds=time.monotonic()-started,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), records=records,
)
(root/'AGGREGATE_AUDIT.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'records'}, indent=2))
