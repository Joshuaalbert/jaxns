"""Retry unchanged evidence analysis with explicit null undefined correlations.

Only nonfinite correlation diagnostics may be encoded as null. A nonfinite
scientific estimator or any other field remains a fatal error. This operational
wrapper leaves the frozen scientific source and raw arrays untouched.
"""

import hashlib
import json
import math
import os
from pathlib import Path
import runpy
import sys


os.sched_setaffinity(0, {int(sys.argv[sys.argv.index('--cpu') + 1])})
folder = Path(sys.argv[sys.argv.index('--run') + 1])
source = Path(__file__)
raw_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in folder.glob('*.npz')}
from benchmarks.issue_312 import tuning_common  # noqa: E402


original_writer = tuning_common.atomic_json
replacements = []


def sanitise(value, path=(), correlation=False):
    """Mutate only undefined correlation leaves; preserve all finite values."""
    if isinstance(value, dict):
        for key in value:
            allowed = key in ('correlations', 'squared_coordinate_correlations')
            allowed |= key.startswith(('corr_x', 'corr_squared_x'))
            value[key] = sanitise(value[key], path + (key,), allowed)
    elif isinstance(value, list):
        for index in range(len(value)):
            value[index] = sanitise(value[index], path + (index,), correlation)
    elif isinstance(value, float) and not math.isfinite(value):
        if not correlation:
            raise ValueError(f'Unexpected nonfinite non-correlation field at {path}')
        replacements.append(list(path))
        return None
    return value


def write_with_null_correlations(path, payload):
    original_writer(path, sanitise(payload))


tuning_common.atomic_json = write_with_null_correlations
runpy.run_module('benchmarks.issue_312.analyse_reflection_tuning', run_name='__main__')
for name, digest in raw_hashes.items():
    assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == digest
receipt = dict(
    passed=True,
    correction='Undefined nonfinite correlation diagnostics encoded as null',
    source_commit='47a9384388d67063f53170ba91ec702d1fc78077',
    wrapper_source=str(source), wrapper_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    frozen_source_unchanged=True, raw_inputs_unchanged=True,
    initial_raw_sha256=raw_hashes, null_replacements=replacements,
    output_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in folder.glob('*.json')},
)
original_writer(folder / 'SERIALIZATION-RETRY.json', receipt)
print(json.dumps({'serialization_retry_passed': True, 'null_replacements': replacements}))
