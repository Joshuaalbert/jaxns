"""Coordinator checks held-out raw draws using separate NumPy/SciPy formulas."""

import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.special import betainc
from scipy.stats import kstest, ks_2samp


root = Path('/largedata/albert/jaxns-reflection-tuning-20261027')
validation = json.loads((root/'validation/VALIDATION.json').read_text())
schedule_path = root/'calibration/SCHEDULE.json'
schedule = json.loads(schedule_path.read_text())
assert validation['passed'] and len(validation['records']) == 12
assert validation['schedule_sha256'] == hashlib.sha256(schedule_path.read_bytes()).hexdigest()
scale = float(np.float32(.05))
def residual(points):
    return np.column_stack([
        (points[:,0]-.5-.3*np.sin(2*np.pi*points[:,1]))/1e-5,
        (points[:,2:16]-.5)/scale,
    ])

records=[]
seen=set()
for record in validation['records']:
    case,arm=record['case'],record['arm']
    assert (case,arm) not in seen
    seen.add((case,arm))
    gap=np.inf if record['gap']=='infinity' else record['gap']
    path=root/'validation'/f'case-{case}-{arm}.npz'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['archive_sha256']
    with np.load(path,allow_pickle=False) as arrays:
        data=dict(arrays)
    initial=data['initial']
    n=len(initial)
    assert n==8192 and initial.shape==(n,18)
    assert data['accepted'].sum()==record['accepted_paths']
    np.testing.assert_equal(data['accepted'].mean(),record['single_path_acceptance'])
    np.testing.assert_equal(data['chain_accepted'].sum()/(9*n),record['full_chain_path_acceptance'])
    expected_h=.003
    if arm=='tuned' and gap<=49:
        expected_h=float(np.exp(np.interp(np.log(max(gap,schedule['gaps'][0])),
                                         np.log(schedule['gaps']),np.log(schedule['steps']))))
    np.testing.assert_allclose(record['h'],expected_h,rtol=2e-15,atol=0)
    assert np.all(data['realised_steps'] >= .8*record['h'])
    assert np.all(data['realised_steps'] <= 1.2*record['h'])
    for law,name in [('single_path','path_points'),('full_chain','final_points')]:
        x=data[name]
        assert x.dtype==np.float64 and x.shape==(n,18)
        assert np.all((x>=0)&(x<=1))
        assert np.all(np.sum(residual(x)**2,axis=1)<2*gap)
        if gap<50:
            u=np.column_stack([x[:,[1,16,17]],
                               betainc(8,8,(residual(x)/np.sqrt(2*gap)+1)/2),
                               (np.sum(residual(x)**2,axis=1)/(2*gap))**7.5])
            statistics=[float(kstest(v,'uniform').statistic) for v in u.T]
        elif np.isposinf(gap):
            statistics=[float(kstest(v,'uniform').statistic) for v in x.T]
        else:
            ref=data['independent_reference']
            left=np.column_stack([x,residual(x),np.linalg.norm(residual(x),axis=1)])
            right=np.column_stack([ref,residual(ref),np.linalg.norm(residual(ref),axis=1)])
            statistics=[float(ks_2samp(a,b).statistic) for a,b in zip(left.T,right.T,strict=True)]
        np.testing.assert_allclose(statistics,record['stationarity'][law]['ks'],rtol=0,atol=2e-14)
        assert max(statistics)<record['stationarity'][law]['limit']
    np.testing.assert_allclose(np.sqrt(np.mean((data['final_points']-initial)**2,axis=0)),
                               record['chain_rms'],rtol=0,atol=0)
    np.testing.assert_array_equal(data['path_points'][~data['accepted']],initial[~data['accepted']])
    if case>=3 and arm=='tuned':
        with np.load(root/'validation'/f'case-{case}-fixed.npz') as fixed:
            for field in ('initial','path_points','accepted','final_points','final_log_likelihood',
                          'chain_accepted','evaluations'):
                np.testing.assert_array_equal(data[field],fixed[field])
    records.append({'case':case,'arm':arm,'gap':record['gap'],'h':record['h'],
                    'acceptance':record['single_path_acceptance'],'passed':True})
assert seen=={(case,arm) for case in range(6) for arm in ('fixed','tuned')}
report={'passed':True,'cases':12,'single_path_and_full_chain_cases':24,
        'exact_early_control_parity':True,'rejected_path_self_transitions':True,
        'schedule_sha256':validation['schedule_sha256'],'records':records,
        'audit_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root/'coordinator-audits/HELDOUT_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
