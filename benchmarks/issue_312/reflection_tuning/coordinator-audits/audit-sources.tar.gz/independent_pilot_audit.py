"""Coordinator's independent NumPy audit; do not import experiment helpers."""

import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.special import betainc
from scipy.stats import kstest


root = Path('/largedata/albert/jaxns-reflection-tuning-20261027')
schedule_path = root / 'calibration/SCHEDULE.json'
schedule_bytes = schedule_path.read_bytes()
schedule = json.loads(schedule_bytes)
peak = schedule['peak']
scale = float(np.float32(0.05))
assert len(schedule['nodes']) == 40
assert schedule['paths'] == 40 * 64 * 256
assert schedule['model_calls'] == schedule['paths'] * 11
assert schedule['gradient_calls'] == schedule['paths'] * 10
checked = []
all_keys = []
for k, node in enumerate(schedule['nodes']):
    gap = 49 * np.exp(-2 * k / 15)
    np.testing.assert_equal(node['gap'], gap)
    archive = root / 'calibration' / f'node-{k:02d}.npz'
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert digest == node['archive_sha256']
    with np.load(archive, allow_pickle=False) as data:
        initial = data['initial']
        proposed = data['proposed']
        accepted = data['accepted']
        log_steps = data['log_steps']
        realised = data['realised_step']
        keys = data['keys']
    assert initial.shape == proposed.shape == (16384, 18)
    assert initial.dtype == proposed.dtype == np.float64
    assert np.all((initial >= 0) & (initial <= 1))
    assert np.all((proposed >= 0) & (proposed <= 1))
    residual = np.column_stack([
        (initial[:, 0] - .5 - .3 * np.sin(2*np.pi*initial[:, 1])) / 1e-5,
        (initial[:, 2:16] - .5) / scale,
    ])
    proposed_residual = np.column_stack([
        (proposed[:, 0] - .5 - .3 * np.sin(2*np.pi*proposed[:, 1])) / 1e-5,
        (proposed[:, 2:16] - .5) / scale,
    ])
    squared = np.sum(residual**2, axis=1)
    proposed_squared = np.sum(proposed_residual**2, axis=1)
    assert np.all(squared < 2*gap)
    independent_acceptance = proposed_squared < 2*gap
    np.testing.assert_array_equal(accepted, independent_acceptance)
    log_h = np.log(.003)
    for t, batch in enumerate(node['batches']):
        fraction = accepted[t*256:(t+1)*256].mean()
        np.testing.assert_equal(batch['acceptance'], fraction)
        assert batch['accepted'] == int(accepted[t*256:(t+1)*256].sum())
        assert batch['total'] == 256
        np.testing.assert_equal(log_steps[t], log_h)
        np.testing.assert_equal(batch['step'], np.exp(log_h))
        eta = .8/(1+t/8)**.6
        log_h = np.clip(log_h+eta*(fraction-.7), np.log(1e-6), np.log(.03))
    np.testing.assert_equal(node['step'], np.exp(np.mean(log_steps[48:64])))
    ratios = realised / np.repeat(np.exp(log_steps), 256)
    assert np.all((ratios >= .8) & (ratios <= 1.2))
    pits = np.column_stack([
        initial[:, [1, 16, 17]],
        betainc(8, 8, (residual/np.sqrt(2*gap)+1)/2),
        (squared/(2*gap))**7.5,
    ])
    ks = [float(kstest(column, 'uniform').statistic) for column in pits.T]
    assert max(ks) < 5/np.sqrt(len(initial))
    all_keys.append(keys)
    checked.append({'node': k, 'gap': float(gap), 'step': node['step'],
                    'accepted': int(accepted.sum()), 'max_initial_pit_ks': max(ks),
                    'archive_sha256': digest})
keys = np.concatenate(all_keys)
assert keys.shape == (655360, 2)
assert len(np.unique(keys, axis=0)) == len(keys)
order = np.argsort([node['gap'] for node in schedule['nodes']])
np.testing.assert_array_equal(schedule['gaps'], [schedule['nodes'][i]['gap'] for i in order])
np.testing.assert_array_equal(schedule['steps'], [schedule['nodes'][i]['step'] for i in order])
report = {'passed': True, 'independent_of_experiment_helpers': True,
          'schedule_sha256': hashlib.sha256(schedule_bytes).hexdigest(),
          'nodes': len(checked), 'paths': len(keys), 'distinct_path_keys': len(keys),
          'numpy_endpoint_decisions_all_equal': True,
          'controller_and_frozen_step_recomputed_exactly': True,
          'maximum_initial_pit_ks': max(row['max_initial_pit_ks'] for row in checked),
          'audit_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'records': checked}
output = root / 'coordinator-audits'
output.mkdir(exist_ok=True)
(output / 'PILOT_AUDIT.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: v for k, v in report.items() if k != 'records'}, indent=2))
